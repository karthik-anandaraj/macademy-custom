import React from 'react';
import './css/Header.css';
import elsiverLogo from './img/els-logo.svg';
import scopus from './img/body-scopus.svg';

const Header = () => {
  return (
    <div className="header-panel col-md-12">
      <h4 className="header-text1">
        Brought to you by <a href="https://service.elsevier.com" className="header-test1-anchor" target="_blank" rel="noopener noreferrer">Elsevier</a>
      </h4>
      <nav className="navbar py-3">
        <div className="navbar-content">
          <a href="https://www.scopus.com" target="_blank" rel="noopener noreferrer">
            <img
              src={elsiverLogo}
              alt="Elsevier Logo"
              height={65}
              className="els-logo"
            />
          </a>
          <a href="https://www.scopus.com" target="_blank" rel="noopener noreferrer">
            <img
              src={scopus}
              alt="Scopus Logo"
              className="scopus-logo"
            />
          </a>
          <span className="text-separator"></span>
          <span className="empowering-text">Empowering discovery since 2004</span>

          <div className="button-container">
            <a href="https://www.scopus.com/signin.uri" target="_blank" rel="noopener noreferrer">
            <button className="create-account-btn">Create Account</button>
            </a>
            <a href="https://www.scopus.com/signin.uri" target="_blank" rel="noopener noreferrer">
            <button className="sign-in-btn">Sign In</button>
            </a>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Header;
