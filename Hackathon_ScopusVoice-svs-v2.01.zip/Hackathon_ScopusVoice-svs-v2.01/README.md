# Hackathon_ScopusVoice
Hackathon 2024 Scopus voice experimentation

# How to execute the code

## Backend:
### `python -m venv scopus`
### `pip install -r requirements.txt`
### `uvicorn scopus_data:app --reload`

## Frontend: 
### `npm install`
### `npm start`