import axios from 'axios';

export const ScopusSearch = async (term) => {
  const { data } = await axios.get(
    //Scopus API
    'f3d71c22cc04d7bc3a4ef5843fe17a6b',
    {
      params: {
        // key: ,
        q: term,
      },
    }
  );
  console.log(data);
  return data;
};
