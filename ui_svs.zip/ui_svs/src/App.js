import React, { useState } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Home } from './components/HomeScreen';
import { ScopusSearch } from './api/ScopusSearch';

const App = (props) => {
  // let history = useNavigate();
  //search term
  const [searchTerm, setSearchTerm] = useState('');
  // serach data
  const [searchData, setSearchData] = useState({});
  //set search term
  const setSearch = async (term) => {
    setSearchTerm(term);
    await setData(term);
  };
  //set search data
  const setData = async (term) => {
    const searches = await ScopusSearch(term);
    setSearchData(searches);
  };

  return (
    <BrowserRouter>
    <Routes>
      <Route
        path={'/'}
        element={ <Home setSearch={setSearch} />}
      />
     </Routes>
     </BrowserRouter>
  );
};

export default App;
