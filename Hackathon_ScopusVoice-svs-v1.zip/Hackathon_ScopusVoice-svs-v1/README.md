# Hackathon_ScopusVoice
Hackathon 2024 Scopus voice experimentation
