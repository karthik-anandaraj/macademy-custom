# Hackathon_ScopusVoice
Hackathon 2024 Scopus voice experimentation

# Installation
The resource tool requires Python 3.12


It is recommended to use `venv` to manage the virtual environments. Make sure that `venv` is installed

```
 $ python -m pip install venv
```

To install:

```
 $ python -m venv venv
```

Setup requirements:

```
 $ venv/bin/python -m pip -r requirements.txt
```