import os
import sys

# Add the src directory to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from textPreProcessing.title_extractor import extract_title_text

file1 = open('./resources/test_searches.txt', 'r')
lines = file1.readlines()
print(lines[0])
for line in lines:
    single_string = extract_title_text(line)
    print("input string : ", linestrip(), "\nfinal string : ", single_string)