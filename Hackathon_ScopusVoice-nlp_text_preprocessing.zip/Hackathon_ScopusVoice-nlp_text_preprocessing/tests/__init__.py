import os
import sys
PROJECT_PATH = os.getcwd()
sys.path.append("../src/textPreProcessing")