import spacy
import re
# Load spaCy model
nlp = spacy.load('en_core_web_sm')
import nltk
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('punkt_tab')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
set(stopwords.words('english'))
import string

translator = str.maketrans('', '', string.punctuation)

def remove_stopwords(text):
    stop_words = set(stopwords.words('english'))
    word_tokens = word_tokenize(text)
    filtered_sentence = [w for w in word_tokens if not w.lower() in stop_words]
    return filtered_sentence

def get_stopwords(text):
    stop_words = set(stopwords.words('english'))
    word_tokens = word_tokenize(text)
    stop_words_sentence = [w for w in word_tokens if w.lower() in stop_words]
    return stop_words_sentence

def get_change(current, previous):
    if current == previous:
        return 0
    try:
        return (abs(current - previous) / previous) * 100.0
    except ZeroDivisionError:
        return float('inf')

def getStringFromKeyWords(keywords):
    single_string = ""
    count = 0
    for item in keywords:
        if (count == 0):
            single_string = item
        else:
            single_string = single_string + " " + item
        count += 1
    return single_string

def extract_title_text(text):
    inputstring = text.strip()
    if (("title" not in inputstring.lower() and "article" not in inputstring.lower() and
         "journal" not in inputstring.lower() and "topic" not in inputstring.lower() and
         "paper" not in inputstring.lower() and "papers" not in inputstring.lower())):
        words = word_tokenize(inputstring)
        stp_wrds = get_stopwords(inputstring)
        if (get_change(len(stp_wrds), len(words)) >= 50):
            words = remove_stopwords(inputstring)
            inputstring = getStringFromKeyWords(words)
    keywords = extract_keywords(inputstring)
    single_string = getStringFromKeyWords(keywords)
    return single_string


def extract_keywords(text):
    # Parse the sentence
    # = re.sub(r'.*?(?=(title|Title|TITLE))', '', text, 1)
    result = text.translate(translator)
    if "title" in result.lower():
        return extract_title(result)
    if "article" in result.lower():
        return extract_title(result)
    if "topic" in result.lower():
        return extract_title(result)
    if "paper" in result.lower():
        return extract_title(result)
    if "journal" in result.lower():
        return extract_title(result)
    return result.split()


def extract_title(text):
    doc = nlp(text)
    # Initialize a list to store the keywords
    keywords = []
    #for tok in doc:
        #print(tok.text, "-->",tok.dep_,"-->", tok.pos_)
    capture = False
    # Iterate through the tokens to find the keywords after "title"
    count = 0
    title_found = False
    prev_dep = ""
    for token in doc:
        if (token.text.lower() == "title" or token.text.lower() == "titles" or
                token.text.lower() == "article" or token.text.lower() == "articles" or
                token.text.lower() == "journal" or token.text.lower() == "journals" or
                token.text.lower() == "topic" or token.text.lower() == "topics" or
                token.text.lower() == "paper" or token.text.lower() == "papers"):
            capture = True
            count += 1
            continue
        elif (token.pos_ == "SPACE"):
            continue
        elif (capture and count >= 1 and (
                token.dep_ == "compound" and (token.text.lower() == "text") or (token.text.lower() == "name"))):
            continue
        elif (capture and token.dep_ != "relcl" and token.dep_ != "ccomp" and token.dep_ != "acl"
              and token.dep_ != "prep"):
            count = 0
            keywords.append(token.text)
            title_found = True
            capture = False
            prev_dep = token.dep_
        elif (title_found):
            if(token.dep_ == "aux"):
                break
            keywords.append(token.text)
    return keywords

# Sample text
#text1 = "find an article where the title is Fully Adaptive Detection-Control System for Isolated Intersections"
#out 1 = Keywords: ['Fully', 'Adaptive', 'Detection', '-', 'Control', 'System', 'for', 'Isolated', 'Intersections']
#text = "get me an article where the title contains Fully Adaptive Detection-Control System for Isolated Intersections"
#out 2 = Fully Adaptive Detection - Control System for Isolated Intersections

#text = "Hi Scopus I want the journal with title contains cell biology"
#text = "find an article where the Title Fully Adaptive Detection-Control System for Isolated Intersections"

#keywords = extract_keywords(text)
#print("Keywords:", keywords)
#single_string = "".join(keywords)
#print("final string",single_string)

